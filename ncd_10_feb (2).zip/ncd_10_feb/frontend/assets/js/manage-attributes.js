import { AttributeAPI } from "./api/attribute.api.js";

let ATTRIBUTES = { msg: [], signal: [], ecu: [], dbc: [] };
let modal;

/* ============================
   SPA INIT FUNCTION
============================ */
export async function initManageAttributesPage() {
  modal = new bootstrap.Modal(document.getElementById("attributeModal"));

  document.getElementById("addAttrBtn").onclick = openModal;
  document.getElementById("saveAttrBtn").onclick = saveAttribute;
  document.getElementById("filterType").onchange = renderTable;
  document.getElementById("searchInput").oninput = renderTable;
  document.getElementById("attrType").onchange = renderTypeFields;

  await loadAttributes();
}

/* ============================
   LOAD DATA (CALLED ONCE)
============================ */
async function loadAttributes() {
  ATTRIBUTES = await AttributeAPI.getAll();
  renderTable();
}

/* ============================
   RENDER
============================ */
function renderTable() {
  const tbody = document.getElementById("attributeTable");
  tbody.innerHTML = "";

  const filter = filterType.value;
  const search = searchInput.value.toLowerCase();

  const cats = filter === "all" ? Object.keys(ATTRIBUTES) : [filter];

  cats.forEach(cat => {
    ATTRIBUTES[cat].forEach((a, i) => {
      if (!a.name.toLowerCase().includes(search)) return;

      tbody.insertAdjacentHTML("beforeend", `
        <tr>
          <td>${a.name}</td>
          <td>${a.type}</td>
          <td>${a.default ?? ""}</td>
          <td>${constraintText(a)}</td>
          <td>${cat.toUpperCase()}</td>
          <td>
            <button class="btn btn-sm btn-warning" onclick="window.editAttr('${cat}',${i})">Edit</button>
            <button class="btn btn-sm btn-danger" onclick="window.delAttr('${cat}',${i})">Delete</button>
          </td>
        </tr>
      `);
    });
  });
}

function constraintText(a) {
  if (a.type === "ENUM") return a.values.join(", ");
  if (a.type === "INT" || a.type === "HEX") return `${a.min}-${a.max}`;
  return "-";
}

/* ============================
   MODAL
============================ */
function openModal() {
  editIndex.value = "";
  attrName.value = "";
  attrType.value = "INT";
  renderTypeFields();
  modal.show();
}

function renderTypeFields(a = {}) {
  if (attrType.value === "ENUM") {
    typeFields.innerHTML = `
      <div id="enumList"></div>
      <button class="btn btn-sm btn-outline-primary mt-2" onclick="addEnum()">+ Add</button>
    `;
    (a.values || []).forEach(v => addEnum(v));
  } else {
    typeFields.innerHTML = `
      <div class="row g-3">
        <div class="col"><input class="form-control" id="defVal" placeholder="Default" value="${a.default ?? ""}"></div>
        <div class="col"><input class="form-control" id="minVal" placeholder="Min" value="${a.min ?? ""}"></div>
        <div class="col"><input class="form-control" id="maxVal" placeholder="Max" value="${a.max ?? ""}"></div>
      </div>
    `;
  }
}

/* ============================
   SAVE / DELETE
============================ */
async function saveAttribute() {
  const cat = attrCategory.value;

  const attr = {
    name: attrName.value,
    type: attrType.value,
    default: defVal?.value,
    min: minVal?.value,
    max: maxVal?.value,
    values: [...document.querySelectorAll(".enumVal")].map(e => e.value)
  };

  ATTRIBUTES[cat].push(attr);
  await AttributeAPI.create({ ...attr, category: cat });

  modal.hide();
  renderTable();
}

/* expose for inline buttons */
window.editAttr = (c,i) => {
  const a = ATTRIBUTES[c][i];
  editIndex.value = i;
  attrName.value = a.name;
  attrCategory.value = c;
  attrType.value = a.type;
  renderTypeFields(a);
  modal.show();
};

window.delAttr = async (c,i) => {
  if (!confirm("Delete attribute?")) return;
  ATTRIBUTES[c].splice(i,1);
  renderTable();
};
