import { login } from "./auth.js";

document.getElementById("loginForm").addEventListener("submit", (e) => {
  e.preventDefault();

  login({
    email: document.getElementById("email").value,
    role: "author"
  });

  window.location.href = "index.html";
});
