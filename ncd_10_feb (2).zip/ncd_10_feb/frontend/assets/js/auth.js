const AUTH_KEY = "ncd_auth";

export function login(user) {
  localStorage.setItem(AUTH_KEY, JSON.stringify(user));
}

export function logout() {
  localStorage.removeItem(AUTH_KEY);
}

export function isLoggedIn() {
  return !!localStorage.getItem(AUTH_KEY);
}

export function getUser() {
  return JSON.parse(localStorage.getItem(AUTH_KEY));
}
