import { API_BASE_URL } from "./config.js";

let messages = [];
async function fetchMessages() {
  try {
    const res = await fetch(`${API_BASE_URL}/api/v1/messages`);
    if (!res.ok) throw new Error("Fetch failed");

    const json = await res.json();

    messages = json.data.map((m) => ({
      id: m.message_id,
      name: m.msg_name,
      ecu: ECU_MAP[m.sender_ecu_id] || `ECU-${m.sender_ecu_id}`,
      channel: CHANNEL_MAP[m.channel_id] || `CH-${m.channel_id}`,
    }));
  } catch (err) {
    console.error(err);
    messages = [];
  }
}

let ECU_MAP = {};
let CHANNEL_MAP = {};

async function fetchLookups() {
  const [ecuRes, channelRes] = await Promise.all([
    fetch(`${API_BASE_URL}/api/v1/ecus`),
    fetch(`${API_BASE_URL}/api/v1/channels`),
  ]);

  const ecus = await ecuRes.json();
  const channels = await channelRes.json();

  ecus.data.forEach((e) => (ECU_MAP[e.ecu_id] = e.ecu_name));
  channels.data.forEach((c) => (CHANNEL_MAP[c.channel_id] = c.channel_name));
}
// ================= STATE =================
let selectedECU = "";
let selectedChannel = "";

// ================= DOM (lazy init) =================
let tbody;
let globalSearch;

// ================= CORE FUNCTIONS =================
function renderTable() {
  const search = globalSearch.value.toLowerCase();

  const filtered = messages.filter(
    (m) =>
      (!selectedECU || m.ecu === selectedECU) &&
      (!selectedChannel || m.channel === selectedChannel) &&
      (!search ||
        `${m.id} ${m.name} ${m.ecu} ${m.channel}`
          .toLowerCase()
          .includes(search)),
  );

  tbody.innerHTML = "";

  filtered.forEach((m) => {
    tbody.insertAdjacentHTML(
      "beforeend",
      `
    <tr>
      <td>${m.id}</td>
      <td>
        <a href="#"
           class="message-link"
           data-msg-id="${m.id}"
           data-msg-name="${encodeURIComponent(m.name)}">
          ${m.name}
        </a>
      </td>
      <td><span class="badge badge-ecu">${m.ecu}</span></td>
      <td><span class="badge badge-channel">${m.channel}</span></td>
      <td class="text-end">
        <button
          class="action-btn view-msg-btn"
          data-msg-id="${m.id}"
          title="View message"
        >
          <i class="bi bi-eye"></i>
        </button>
        <button
          class="action-btn edit-msg-btn"
          data-msg-id="${m.id}"
          title="Edit message"
        >
          <i class="bi bi-pencil"></i>
        </button>        
        <button
          class="action-btn text-danger delete-msg-btn"
          data-msg-id="${m.id}"
          title="Delete message"
        >
          <i class="bi bi-trash"></i>
        </button>
      </td>
    </tr>
    `,
    );
  });

  tbody.querySelectorAll(".delete-msg-btn").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const msgId = btn.dataset.msgId;
      await confirmAndDeleteMessage(msgId);
    });
  });
  tbody.querySelectorAll(".edit-msg-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const msgId = btn.dataset.msgId;
      window.loadPage("add-message", msgId);
    });
  });
  
  tbody.querySelectorAll(".view-msg-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const msgId = btn.dataset.msgId;
      openMessageViewModal(msgId);
    });
  });
  tbody.querySelectorAll(".message-link").forEach((link) => {
    link.addEventListener("click", async (e) => {
      e.preventDefault();

      const msgId = link.dataset.msgId;
      const msgName = decodeURIComponent(link.dataset.msgName);

      await openSignalListModal(msgId, msgName);
    });
  });
}

function populateFilters() {
  const ecuSet = [...new Set(messages.map((m) => m.ecu))];
  const channelSet = [...new Set(messages.map((m) => m.channel))];

  const ecuList = document.getElementById("ecuFilterList");
  const channelList = document.getElementById("channelFilterList");

  ecuList.innerHTML =
    `<div class="filter-item" data-ecu="">All</div>` +
    ecuSet
      .map((e) => `<div class="filter-item" data-ecu="${e}">${e}</div>`)
      .join("");

  channelList.innerHTML =
    `<div class="filter-item" data-channel="">All</div>` +
    channelSet
      .map((c) => `<div class="filter-item" data-channel="${c}">${c}</div>`)
      .join("");

  ecuList.querySelectorAll("[data-ecu]").forEach((el) =>
    el.addEventListener("click", () => {
      selectedECU = el.dataset.ecu;
      renderTable();
      closeDropdowns();
    }),
  );

  channelList.querySelectorAll("[data-channel]").forEach((el) =>
    el.addEventListener("click", () => {
      selectedChannel = el.dataset.channel;
      renderTable();
      closeDropdowns();
    }),
  );
}

function closeDropdowns() {
  document.querySelectorAll(".dropdown-menu").forEach((d) => {
    d.classList.remove("show");
  });
}

export function filterDropdown(input, type) {
  const value = input.value.toLowerCase();
  const listId = type === "ecu" ? "ecuFilterList" : "channelFilterList";

  document.querySelectorAll(`#${listId} .filter-item`).forEach((item) => {
    item.style.display =
      item.textContent === "All" ||
      item.textContent.toLowerCase().includes(value)
        ? "block"
        : "none";
  });
}

async function openSignalListModal(messageId, messageName) {
  // Load signal list HTML
  const res = await fetch("pages/signal-list.html");
  const html = await res.text();

  document.getElementById("signalModalBody").innerHTML = html;
  document.getElementById("signalModalTitle").textContent =
    `Signals – ${messageName}`;

  // Show modal
  const modal = new bootstrap.Modal(document.getElementById("signalListModal"));
  modal.show();

  // Init signal list JS
  const sigModule = await import("../js/Sig-list.js");
  sigModule.initSignalListPage(messageId, messageName);
}

export async function initMessageListPage() {
  // DOM available NOW because router injected HTML
  tbody = document.getElementById("messageTableBody");
  globalSearch = document.getElementById("globalSearch");

  if (!tbody || !globalSearch) {
    console.error("Message List DOM not found");
    return;
  }

  globalSearch.addEventListener("input", renderTable);
  await fetchLookups();
  await fetchMessages();
  populateFilters();
  renderTable();
}
async function confirmAndDeleteMessage(messageId) {
  if (!confirm("Are you sure you want to delete this message?")) return;

  try {
    const res = await fetch(`${API_BASE_URL}/api/v1/messages/${messageId}`, {
      method: "DELETE",
    });

    if (!res.ok) throw new Error("Delete failed");

    // Remove from local state
    messages = messages.filter((m) => m.id !== Number(messageId));

    // Re-render table + filters
    populateFilters();
    renderTable();
  } catch (err) {
    console.error(err);
    alert("Failed to delete message");
  }
}
let currentSignals = []; // Store signals for filtering
let selectedReceiverEcu = ""; // Filter state

async function openMessageViewModal(messageId) {
  try {
    // Fetch message details
    const msg = messages.find((m) => m.id == messageId);

    // Fetch signals for this message
    const res = await fetch(
      `${API_BASE_URL}/api/v1/signals?message_id=${messageId}`,
    );
    if (!res.ok) throw new Error("Signal fetch failed");

    const json = await res.json();
    currentSignals = json.data || [];

    // Fill message info
    document.getElementById("vMsgId").textContent = msg.id;
    document.getElementById("messageViewTitle").textContent =
      `Message – ${msg.name}`;
    document.getElementById("vMsgEcu").textContent = msg.ecu;
    document.getElementById("vMsgChannel").textContent = msg.channel;
    document.getElementById("vMsgSignalCount").textContent = currentSignals.length;

    // Setup search
    const searchInput = document.getElementById("signalSearch");
    searchInput.value = "";
    searchInput.removeEventListener("input", renderSignalTable); // Remove old listeners
    searchInput.addEventListener("input", renderSignalTable);

    // Setup filters
    populateReceiverEcuFilter();
    
    // Render table
    renderSignalTable();

    // Show modal
    new bootstrap.Modal(document.getElementById("messageViewModal")).show();
  } catch (err) {
    console.error(err);
    alert("Unable to load message details");
  }
}

function renderSignalTable() {
  const searchValue = document.getElementById("signalSearch").value.toLowerCase();
  
  // Filter signals
  const filtered = currentSignals.filter((s) => {
    const matchesSearch = !searchValue || 
      `${s.sig_name} ${s.start_bit} ${s.length} ${s.unit || ""}`
        .toLowerCase()
        .includes(searchValue);
    
    const matchesEcu = !selectedReceiverEcu || 
      (s.receiver_ecus && s.receiver_ecus.some(ecu => 
        ECU_MAP[ecu] === selectedReceiverEcu
      ));
    
    return matchesSearch && matchesEcu;
  });

  const tbody = document.getElementById("vSignalTableBody");
  tbody.innerHTML = "";

  if (filtered.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="7" class="text-center text-muted py-3">
          No signals found
        </td>
      </tr>
    `;
    return;
  }

  filtered.forEach((s) => {
    // Format receiver ECUs
    const receiverEcus = s.receiver_ecus && s.receiver_ecus.length > 0
      ? s.receiver_ecus.map(ecuId => ECU_MAP[ecuId] || `ECU-${ecuId}`).join(", ")
      : "-";

    tbody.insertAdjacentHTML(
      "beforeend",
      `
      <tr>
        <td>${s.sig_name}</td>
        <td>${s.start_bit}</td>
        <td>${s.length}</td>
        <td>${s.unit || "-"}</td>
        <td>
          <span class="badge badge-ecu" style="font-size: 0.75rem;">
            ${receiverEcus}
          </span>
        </td>
        <td>${s.endianness}</td>
        <td class="text-end">
          <button
            class="action-btn view-sig-btn"
            data-signal-id="${s.signal_id}"
            title="View signal"
          >
            <i class="bi bi-eye"></i>
          </button>
          <button
            class="action-btn edit-sig-btn"
            data-signal-id="${s.signal_id}"
            title="Edit signal"
          >
            <i class="bi bi-pencil"></i>
          </button>
          <button
            class="action-btn text-danger delete-sig-btn"
            data-signal-id="${s.signal_id}"
            title="Delete signal"
          >
            <i class="bi bi-trash"></i>
          </button>
        </td>
      </tr>
      `,
    );
  });

  // Attach event listeners
  tbody.querySelectorAll(".view-sig-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const signalId = btn.dataset.signalId;
      viewSignalDetails(signalId);
    });
  });

  tbody.querySelectorAll(".edit-sig-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const signalId = btn.dataset.signalId;
      editSignal(signalId);
    });
  });

  tbody.querySelectorAll(".delete-sig-btn").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const signalId = btn.dataset.signalId;
      await deleteSignal(signalId);
    });
  });
}

function populateReceiverEcuFilter() {
  // Get unique receiver ECUs from all signals
  const ecuSet = new Set();
  currentSignals.forEach((s) => {
    if (s.receiver_ecus && s.receiver_ecus.length > 0) {
      s.receiver_ecus.forEach((ecuId) => {
        const ecuName = ECU_MAP[ecuId];
        if (ecuName) ecuSet.add(ecuName);
      });
    }
  });

  const ecuList = document.getElementById("receiverEcuFilterList");
  
  ecuList.innerHTML =
    `<div class="filter-item" data-ecu="">All</div>` +
    [...ecuSet]
      .sort()
      .map((e) => `<div class="filter-item" data-ecu="${e}">${e}</div>`)
      .join("");

  // Attach click handlers
  ecuList.querySelectorAll("[data-ecu]").forEach((el) => {
    el.addEventListener("click", () => {
      selectedReceiverEcu = el.dataset.ecu;
      renderSignalTable();
      
      // Close dropdown
      document.querySelectorAll(".dropdown-menu").forEach((d) => {
        d.classList.remove("show");
      });
    });
  });

  // Setup filter search
  const filterSearch = document.getElementById("receiverEcuFilterSearch");
  filterSearch.value = "";
  filterSearch.removeEventListener("input", filterReceiverEcus);
  filterSearch.addEventListener("input", filterReceiverEcus);
}

function filterReceiverEcus() {
  const value = document.getElementById("receiverEcuFilterSearch").value.toLowerCase();
  
  document.querySelectorAll("#receiverEcuFilterList .filter-item").forEach((item) => {
    item.style.display =
      item.textContent === "All" ||
      item.textContent.toLowerCase().includes(value)
        ? "block"
        : "none";
  });
}

async function viewSignalDetails(signalId) {
  try {
    const signal = currentSignals.find((s) => s.signal_id == signalId);
    if (!signal) {
      alert("Signal not found");
      return;
    }

    // Format receiver ECUs
    const receiverEcus = signal.receiver_ecus && signal.receiver_ecus.length > 0
      ? signal.receiver_ecus.map(ecuId => ECU_MAP[ecuId] || `ECU-${ecuId}`).join(", ")
      : "None";

    // Build detail view
    const detailHtml = `
      <div class="container-fluid">
        <div class="row mb-3">
          <div class="col-md-6">
            <strong>Signal Name:</strong> ${signal.sig_name}
          </div>
          <div class="col-md-3">
            <strong>Start Bit:</strong> ${signal.start_bit}
          </div>
          <div class="col-md-3">
            <strong>Length:</strong> ${signal.length}
          </div>
        </div>

        <div class="row mb-3">
          <div class="col-md-6">
            <strong>Receiver ECUs:</strong> ${receiverEcus}
          </div>
          <div class="col-md-3">
            <strong>Endianness:</strong> ${signal.endianness}
          </div>
          <div class="col-md-3">
            <strong>Unit:</strong> ${signal.unit || "-"}
          </div>
        </div>

        <div class="row mb-3">
          <div class="col-md-3">
            <strong>Signed:</strong> ${signal.is_signed ? "Yes" : "No"}
          </div>
          <div class="col-md-3">
            <strong>Float:</strong> ${signal.is_float ? "Yes" : "No"}
          </div>
          <div class="col-md-3">
            <strong>Multiplexed:</strong> ${signal.is_multiplexed ? "Yes" : "No"}
          </div>
          <div class="col-md-3">
            <strong>Multiplex Value:</strong> ${signal.multiplex_val || "-"}
          </div>
        </div>

        <div class="row mb-3">
          <div class="col-md-3">
            <strong>Factor:</strong> ${signal.factor}
          </div>
          <div class="col-md-3">
            <strong>Offset:</strong> ${signal.offset}
          </div>
          <div class="col-md-3">
            <strong>Min Value:</strong> ${signal.min_value || "-"}
          </div>
          <div class="col-md-3">
            <strong>Max Value:</strong> ${signal.max_value || "-"}
          </div>
        </div>

        <div class="row mb-3">
          <div class="col-md-12">
            <strong>Initial Value:</strong> ${signal.initial_value || "-"}
          </div>
        </div>

        ${signal.comment ? `
        <div class="row mb-3">
          <div class="col-md-12">
            <strong>Comment:</strong><br>
            <p class="text-muted">${signal.comment}</p>
          </div>
        </div>
        ` : ""}

        ${signal.valueDesc && Object.keys(signal.valueDesc).length > 0 ? `
        <div class="row">
          <div class="col-md-12">
            <strong>Value Descriptions:</strong>
            <table class="table table-sm table-bordered mt-2">
              <thead>
                <tr>
                  <th>Key</th>
                  <th>Value</th>
                </tr>
              </thead>
              <tbody>
                ${Object.entries(signal.valueDesc).map(([key, val]) => `
                  <tr>
                    <td>${key}</td>
                    <td>${val}</td>
                  </tr>
                `).join("")}
              </tbody>
            </table>
          </div>
        </div>
        ` : ""}
      </div>
    `;

    document.getElementById("signalDetailTitle").textContent = `Signal – ${signal.sig_name}`;
    document.getElementById("signalDetailBody").innerHTML = detailHtml;

    new bootstrap.Modal(document.getElementById("signalDetailModal")).show();
  } catch (err) {
    console.error(err);
    alert("Unable to load signal details");
  }
}

function editSignal(signalId) {
  const messageModal = bootstrap.Modal.getInstance(
    document.getElementById("messageViewModal")
  );
  if (messageModal) messageModal.hide();

  // Navigate with signal_id
  window.loadPage("addSig",signalId);
}


async function deleteSignal(signalId) {
  if (!confirm("Are you sure you want to delete this signal?")) return;

  try {
    const res = await fetch(`${API_BASE_URL}/api/v1/signals/${signalId}`, {
      method: "DELETE",
    });

    if (!res.ok) throw new Error("Delete failed");

    // Remove from current signals array
    currentSignals = currentSignals.filter((s) => s.signal_id != signalId);

    // Update signal count
    document.getElementById("vMsgSignalCount").textContent = currentSignals.length;

    // Re-render table
    populateReceiverEcuFilter();
    renderSignalTable();

    alert("Signal deleted successfully");
  } catch (err) {
    console.error(err);
    alert("Failed to delete signal");
  }
}