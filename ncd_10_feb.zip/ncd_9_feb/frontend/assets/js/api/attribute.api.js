import { API_BASE_URL } from "../config.js";

export const AttributeAPI = {
  getAll() {
    return fetch(`${API_BASE_URL}/api/v1/attributes`).then(r => r.json());
  },

  create(data) {
    return fetch(`${API_BASE_URL}/api/v1/attributes`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data)
    });
  },

  update(id, data) {
    return fetch(`${API_BASE_URL}/api/v1/attributes/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data)
    });
  },

  delete(id) {
    return fetch(`${API_BASE_URL}/api/v1/attributes/${id}`, { method: "DELETE" });
  }
};
