import { API_BASE_URL } from "./config.js";

const ENDPOINT_MAP = {
  ecu: `/api/v1/ecus`,
  msg: `/api/v1/messages`,
  signal: `/api/v1/signals`,
  dbc: `/api/v1/metadata`
};

export function initAddAttributePage() {
  let SELECTED_OBJECT_ID = null;
  let OBJECT_CACHE = [];

  const objectInput = document.getElementById("objectInput");
  const objectList = document.getElementById("objectList");
  const attributeType = document.getElementById("attributeType");
  const objectDiv = document.getElementById("objectDiv");
  const attributeFields = document.getElementById("attributeFields");
  const saveBtn = document.querySelector(".btn-success");

  if (!attributeType) return;

  /* ================= DATA ================= */
  const data = {
    msg: {
      objects: ["Msg_EngineData", "Msg_Speed", "Msg_Diag"],
      attributes: [
        { name: "NmMessage", type: "ENUM", default: "No", values: ["No", "Yes"] },
        { name: "NmAsrMessage", type: "ENUM", default: "No", values: ["Select", "No", "Yes"] },
        { name: "MessageTimeout", type: "INT", default: 500, min: 0, max: 65535 },
        { name: "GenMsgStartDelayTime", type: "INT", default: 0, min: 0, max: 0 },
        {
          name: "GenMsgSendType",
          type: "ENUM",
          default: "Cyclic",
          values: [
            "Cyclic","Event","NotUsed","NotUsed","NotUsed",
            "NotUsed","NotUsed","IfActive","NoMsgSendType","NotUsed"
          ]
        },
        { name: "GenMsgNrOfRepetition", type: "INT", default: 0, min: 0, max: 0 },
        { name: "GenMsgILSupport", type: "ENUM", default: "Yes", values: ["No", "Yes"] },
        { name: "GenMsgDelayTime", type: "INT", default: 0, min: 0, max: 100 },
        { name: "GenMsgCycleTimeFast", type: "INT", default: 0, min: 0, max: 80 },
        { name: "GenMsgCycleTime", type: "INT", default: 0, min: 0, max: 300 },
        { name: "DiagUudtResponse", type: "ENUM", default: "false", values: ["false", "true"] },
        { name: "DiagUsdtResponse", type: "ENUM", default: "false", values: ["false", "true"] },
        { name: "DiagState", type: "ENUM", default: "No", values: ["No", "Yes"] },
        { name: "DiagResponse", type: "ENUM", default: "No", values: ["No", "Yes"] },
        { name: "DiagRequest", type: "ENUM", default: "No", values: ["No", "Yes"] },
        { name: "MsgType", type: "ENUM", default: "Application", values: ["Application", "NM", "NMH"] }
      ]
    },

    signal: {
      objects: ["Sig_Speed", "Sig_RPM", "Sig_Temp"],
      attributes: [
        { name: "Remarks", type: "STRING", default: "null" },
        { name: "NWM_WakeupAllowed", type: "ENUM", default: "No", values: ["No", "Yes"] },
        { name: "GenSigStartValue", type: "INT", default: 0, min: 0, max: 0 },
        {
          name: "GenSigSendType",
          type: "ENUM",
          default: "Cyclic",
          values: [
            "Cyclic","OnWrite","OnWriteWithRepetition","OnChange",
            "OnChangeWithRepetition","IfActive","IfActiveWithRepetition",
            "NoSigSendType","NotUsed","NotUsed","NotUsed","NotUsed","NotUsed"
          ]
        },
        { name: "GenSigInactiveValue", type: "INT", default: 0, min: 0, max: 0 },
        { name: "GenSigEnvVarType", type: "ENUM", default: "undef", values: ["int", "float", "undef"] },
        { name: "GenSigCycleTimeActive", type: "INT", default: 0, min: 0, max: 0 },
        { name: "GenSigCycleTime", type: "INT", default: 0, min: 0, max: 0 },

        // TIMEOUTS
        { name: "GenSigTimeoutTime_IVI", type: "INT", default: 500, min: 0, max: 65535 },
        { name: "GenSigTimeoutMSignalAttributeIVI", type: "INT", default: 500, min: 0, max: 65535 },
        { name: "GenSigTimeoutTime_HU_Mid_X445", type: "INT", default: 500, min: 0, max: 65535 },
        { name: "GenSigTimeoutTime_HU_High_X445", type: "INT", default: 500, min: 0, max: 65535 },
        { name: "GenSigTimeoutMSignalAttributeHU_Mid_X445", type: "INT", default: 500, min: 0, max: 65535 },
        { name: "GenSigTimeoutMSignalAttributeHU_High_X445", type: "INT", default: 500, min: 0, max: 65535 },
        { name: "GenSigTimeoutMSignalAttributeHU_A", type: "INT", default: 500, min: 0, max: 65535 },
        { name: "GenSigTimeoutMSignalAttributeHU_B", type: "INT", default: 500, min: 0, max: 65535 },
        { name: "GenSigTimeoutMSignalAttributeHU_High_X451", type: "INT", default: 500, min: 0, max: 65535 },
        { name: "GenSigTimeoutMSignalAttributeHU_Mid_X451", type: "INT", default: 500, min: 0, max: 65535 },
        { name: "GenSigTimeoutTime_BCM_Mid", type: "INT", default: 500, min: 0, max: 65535 },
        { name: "GenSigTimeoutTime_HU_A", type: "INT", default: 500, min: 0, max: 65535 },
        { name: "GenSigTimeoutTime_HU_B", type: "INT", default: 500, min: 0, max: 65535 },
        { name: "GenSigTimeoutTime_HU_High_X451", type: "INT", default: 500, min: 0, max: 65535 },
        { name: "GenSigTimeoutTime_HU_Mid_X451", type: "INT", default: 500, min: 0, max: 65535 }
      ]
    },

    ecu: {
      objects: ["ECU_BCM", "ECU_HU", "ECU_TCU"],
      attributes: [
        { name: "NodeLayerModules", type: "STRING", default: "null" },
        { name: "NmStationAddress", type: "INT", default: 0, min: 0, max: 63 },
        { name: "NmNode", type: "ENUM", default: "No", values: ["No", "Yes"] },
        { name: "NmCAN", type: "INT", default: 3, min: 1, max: 3 },
        { name: "NmAsrNodeIdentifier", type: "HEX", default: 2, min: 0, max: 255 },
        { name: "NmAsrNode", type: "ENUM", default: "<n.a.>", values: ["<n.a.>", "No", "Yes"] },
        { name: "NmAsrCanMsgReducedTime", type: "INT", default: 50, min: 1, max: 65535 },
        { name: "NmAsrCanMsgCycleOffs", type: "INT", default: 0, min: 0, max: 65535 },
        { name: "ILUsed", type: "ENUM", default: "No", values: ["Yes", "No"] },
        { name: "ECU", type: "STRING", default: "" }
      ]
    },

    dbc: {
      objects: ["MainDBC", "DiagDBC"],
      attributes: [
        { name: "NmType", type: "STRING", default: "NmAsr" },
        { name: "NmMessageCount", type: "INT", default: 128, min: 0, max: 128 },
        { name: "NmBaseAddress", type: "HEX", default: 0, min: 0, max: 0 },
        { name: "NmAsrWaitBusSleepTime", type: "INT", default: 500, min: 1, max: 65535 },
        { name: "NmAsrTimeoutTime", type: "INT", default: 1000, min: 1, max: 65535 },
        { name: "NmAsrRepeatMessageTime", type: "INT", default: 1500, min: 1, max: 65535 },
        { name: "NmAsrMessageCount", type: "INT", default: 128, min: 128, max: 128 },
        { name: "NmAsrCanMsgCycleTime", type: "INT", default: 200, min: 1, max: 65535 },
        { name: "NmAsrBaseAddress", type: "HEX", default: 1280, min: 0, max: 2047 },
        { name: "Manufacturer", type: "STRING", default: "TML" },
        { name: "ILTxTimeout", type: "INT", default: 500, min: 0, max: 65535 },
        { name: "GenEnvVarPrefix", type: "STRING", default: "Env" },
        { name: "GenEnvVarEndingSnd", type: "STRING", default: "_" },
        { name: "GenEnvVarEndingDsp", type: "STRING", default: "Dsp_" },
        { name: "DBName", type: "STRING", default: "TestDatabase" },
        { name: "BusType", type: "STRING", default: "" },
        { name: "Baudrate", type: "INT", default: 500000, min: 0, max: 1000000 },
        { name: "SystemSignalLongSymbol", type: "STRING", default: "" }
      ]
    }
  };

  /* ================= EVENTS ================= */
  attributeType.addEventListener("change", async () => {
    const type = attributeType.value;
  
    attributeFields.innerHTML = "";
    objectInput.value = "";
    objectList.innerHTML = "";
    SELECTED_OBJECT_ID = null;
  
    if (!type) {
      objectDiv.classList.add("d-none");
      return;
    }
  
    objectDiv.classList.remove("d-none");
  
    await loadObjects(type);
    renderAttributes(data[type].attributes);
  });

  async function loadObjects(type) {
    try {
      const res = await fetch(`${API_BASE_URL}${ENDPOINT_MAP[type]}`);
      const json = await res.json();
  
      if (!json.success) {
        alert(json.message || "Failed to load data");
        return;
      }
  
      // 🔁 MAP backend response → UI list
      if (type === "msg") {
        OBJECT_CACHE = json.data.map(item => ({
          id: item.message_id,
          name: item.msg_name
        }));
      } else if (type === "ecu") {
        OBJECT_CACHE = json.data.map(item => ({
          id: item.ecu_id,
          name: item.ecu_name
        }));
      } else if (type === "signal") {
        OBJECT_CACHE = json.data.map(item => ({
          id: item.signal_id,
          name: item.sig_name
        }));
      } else if (type === "dbc") {
        OBJECT_CACHE = json.data.map(item => ({
          id: item.id,
          name: item.fileName
        }));
      }
    } catch (err) {
      console.error(err);
      alert("Failed to load list");
    }
  }
  
  function renderObjectList(list) {
    objectList.innerHTML = "";
  
    list.forEach(obj => {
      const li = document.createElement("li");
      li.className = "list-group-item list-group-item-action";
      li.textContent = obj.name;
  
      li.onclick = () => {
        objectInput.value = obj.name;
        SELECTED_OBJECT_ID = obj.id;
        objectList.innerHTML = "";
      };
  
      objectList.appendChild(li);
    });
  }

  objectInput.addEventListener("input", () => {
    const key = objectInput.value.toLowerCase();
    const filtered = OBJECT_CACHE.filter(o =>
      o.name.toLowerCase().includes(key)
    );
    renderObjectList(filtered);
  });

  objectInput.addEventListener("focus", () => {
    renderObjectList(OBJECT_CACHE);
  });

  document.addEventListener("click", e => {
    if (!objectDiv.contains(e.target)) {
      objectList.innerHTML = "";
    }
  });

  function renderAttributes(attributes) {
    attributeFields.innerHTML = "";
  
    attributes.forEach(attr => {
      const div = document.createElement("div");
      div.className = "mb-3";
  
      const label = document.createElement("label");
      label.className = "form-label";
      label.textContent = attr.name;
  
      let field;
  
      if (attr.type === "ENUM") {
        field = document.createElement("select");
        field.className = "form-select";
  
        attr.values.forEach(v => {
          const o = document.createElement("option");
          o.value = v;
          o.textContent = v;
          field.appendChild(o);
        });
      } else {
        field = document.createElement("input");
        field.className = "form-control";
        field.type = attr.type === "INT" ? "number" : "text";
        if (attr.min !== undefined) field.min = attr.min;
        if (attr.max !== undefined) field.max = attr.max;
      }
  
      // ✅ Store metadata
      field.dataset.attrName = attr.name;
      field.dataset.attrType = attr.type;
      field.value = attr.default ?? "";
  
      div.appendChild(label);
      div.appendChild(field);
      attributeFields.appendChild(div);
    });
  }

  saveBtn.addEventListener("click", async () => {
    const type = attributeType.value;
  
    if (!type) {
      alert("Please select attribute type");
      return;
    }

    if (!SELECTED_OBJECT_ID) {
      alert("Please select an object from the list");
      return;
    }
  
    const inputs = attributeFields.querySelectorAll("input, select");
  
    // ✅ Build payload array with CORRECT structure
    const payload = [];
  
    for (const input of inputs) {
      const attrData = buildPayload(type, input, SELECTED_OBJECT_ID);
      payload.push(attrData);
    }

    console.log("Sending payload:", JSON.stringify(payload, null, 2));
  
    try {
      const res = await fetch(`${API_BASE_URL}/api/v1/attributes`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
  
      if (!res.ok) {
        const err = await res.json();
        console.error("Backend error:", err);
        alert("Failed to save attributes: " + (err.detail || "Unknown error"));
        return;
      }

      const result = await res.json();
      alert("Attributes saved successfully ✅");
      
      // Reset form
      attributeFields.innerHTML = "";
      objectInput.value = "";
      SELECTED_OBJECT_ID = null;
  
    } catch (err) {
      console.error("Request error:", err);
      alert("Backend not reachable");
    }
  });
  
  function buildPayload(type, input, objectId) {
    // ✅ FIXED: Include 'name' and 'data_type' fields as required by backend
    const payload = {
      name: input.dataset.attrName,           
      data_type: input.dataset.attrType,      
      attribute_name: input.dataset.attrName, 
      ecu_id: null,
      message_id: null,
      signal_id: null,
      int_value: null,
      float_value: null,
      string_value: null
    };
  
    // Set the correct foreign key based on type
    if (type === "ecu") payload.ecu_id = objectId;
    if (type === "msg") payload.message_id = objectId;
    if (type === "signal") payload.signal_id = objectId;
  
    // Set the value in the correct field based on data type
    if (input.dataset.attrType === "INT") {
      payload.int_value = input.value ? Number(input.value) : null;
    } else if (input.dataset.attrType === "FLOAT") {
      payload.float_value = input.value ? Number(input.value) : null;
    } else {
      // STRING, ENUM, HEX all go to string_value
      payload.string_value = input.value || null;
    }
  
    return payload;
  }
}